<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('coin_transactions', function (Blueprint $table) {
        $table->id();
        $table->dateTime('transaction_datetime')->default(now());
        
        $table->unsignedBigInteger('user_id');
        $table->foreign('user_id')->references('id')->on('users');

        // Link to the Transaction Type
        $table->unsignedBigInteger('coin_transaction_type_id');
        $table->foreign('coin_transaction_type_id')->references('id')->on('coin_transaction_types');

        // Optional links to Gameplay
        $table->unsignedBigInteger('match_id')->nullable();
        $table->foreign('match_id')->references('id')->on('matches');

        $table->unsignedBigInteger('game_id')->nullable();
        $table->foreign('game_id')->references('id')->on('games');

        $table->integer('coins'); // Can be positive or negative
        $table->json('custom')->nullable();
        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('coin_transaction_types');
    }
};
