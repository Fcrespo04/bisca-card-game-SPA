<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('coin_purchases', function (Blueprint $table) {
        $table->id();
        $table->dateTime('purchase_datetime')->default(now());

        $table->unsignedBigInteger('user_id');
        $table->foreign('user_id')->references('id')->on('users');

        // Link to the specific transaction that added the coins
        $table->unsignedBigInteger('coin_transaction_id');
        $table->foreign('coin_transaction_id')->references('id')->on('coin_transactions');

        $table->decimal('euros', 8, 2);
        
        // Accepted Payment Methods
        $table->enum('payment_type', ['MBWAY', 'IBAN', 'MB', 'VISA', 'PAYPAL']);
        $table->string('payment_reference', 255);
        
        $table->json('custom')->nullable();
        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('coin_purchases');
    }
};
