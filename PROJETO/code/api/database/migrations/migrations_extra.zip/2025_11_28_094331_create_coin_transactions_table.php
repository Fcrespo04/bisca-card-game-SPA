<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {    
        Schema::create('coin_transaction_types', function (Blueprint $table) {
            $table->id();
            $table->string('name', 40); // e.g. "Welcome Bonus"
            $table->enum('type', ['C', 'D']); // 'C'redit (add), 'D'ebit (remove)
            $table->softDeletes();
            $table->json('custom')->nullable();
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('coin_transactions');
    }
};
