<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 'matches' as the table name, even though the model is 'GameMatch'
        Schema::create('matches', function (Blueprint $table) {
            $table->id();
            
            // Match Type: Bisca de 3 or Bisca de 9
            $table->enum('type', ['3', '9']); 

            // Players
            $table->unsignedBigInteger('player1_user_id');
            $table->foreign('player1_user_id')->references('id')->on('users');

            $table->unsignedBigInteger('player2_user_id')->nullable();
            $table->foreign('player2_user_id')->references('id')->on('users');

            // Winner / Loser
            $table->unsignedBigInteger('winner_user_id')->nullable();
            $table->foreign('winner_user_id')->references('id')->on('users');

            $table->unsignedBigInteger('loser_user_id')->nullable();
            $table->foreign('loser_user_id')->references('id')->on('users');

            // Status
            $table->enum('status', ['PE', 'PL', 'E', 'I'])->default('PE'); 
            
            // Economy
            $table->integer('stake')->default(0); 

            // Timing
            $table->dateTime('began_at')->nullable();
            $table->dateTime('ended_at')->nullable();
            $table->decimal('total_time', 8, 2)->nullable();

            // Scores (Marks = Match Score, Points = Cumulative Game Points)
            $table->integer('player1_marks')->default(0);
            $table->integer('player2_marks')->default(0);
            $table->integer('player1_points')->default(0); 
            $table->integer('player2_points')->default(0);

            $table->json('custom')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('matches');
    }
};